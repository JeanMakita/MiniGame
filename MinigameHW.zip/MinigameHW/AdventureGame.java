package MinigameHW;

import java.io.IOException;

public class AdventureGame {
    public static void main(String[] args) {
        try {
            Game game = new Game("C:\\Users\\makit\\AppData\\Roaming\\JetBrains\\IntelliJIdea2022.3\\AdvancedProgrammingSummer\\src\\MinigameHW\\Rooms.txt");
            game.play();
        } catch (IOException ex) {
            System.err.println("Room file not available: " + ex.getMessage());
        }
    }
}