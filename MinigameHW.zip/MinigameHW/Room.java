package MinigameHW;

import java.util.HashMap;
import java.util.Map;

public class Room {
    private int roomId;
    private String roomName;
    private String description;
    private boolean visited;
    private Map<String, Integer> exits;

    public Room(int roomId, String roomName, String description, boolean visited) {
        this.roomId = roomId;
        this.roomName = roomName;
        this.description = description;
        this.visited = visited;
        this.exits = new HashMap<>();
    }

    public int getRoomId() {
        return roomId;
    }

    public String getRoomName() {
        return roomName;
    }

    public String getDescription() {
        return description;
    }

    public boolean isVisited() {
        return visited;
    }

    public Map<String, Integer> getExits() {
        return exits;
    }

    public void setRoomId(int roomId) {
        this.roomId = roomId;
    }

    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setVisited(boolean visited) {
        this.visited = visited;
    }

    public void addExit(String direction, int roomId) {
        exits.put(direction.toUpperCase(), roomId);
    }

    public void displayRoom() {
        System.out.println(roomName + " (" + (visited ? "Visited" : "Not Visited") + ")");
        System.out.println(description);
        System.out.println("Exits:");
        for (String direction : exits.keySet()) {
            System.out.print(direction + " ");
        }
        System.out.println();
    }
}