package MinigameHW;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Game {
    private Map<Integer, Room> rooms;
    private Room currentRoom;

    public Game(String filepath) throws IOException {
        rooms = new HashMap<>();
        loadRooms(filepath);
        currentRoom = rooms.get(1);

        if (currentRoom == null) {
            throw new IllegalStateException("The initial room (ID 1) does not exist. Please check the room data file.");
        }
    }

    private void loadRooms(String filePath) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(filePath));
        String line;
        Room room = null;

        while ((line = br.readLine()) != null) {
            if (line.startsWith("ID = ")) {
                if (room != null) {
                    rooms.put(room.getRoomId(), room);
                }
                int id = Integer.parseInt(line.substring(5).trim());
                String name = br.readLine().substring(7).trim();
                StringBuilder description = new StringBuilder();
                while (!(line = br.readLine()).equals("Exits")) {
                    description.append(line).append("\n");
                }
                room = new Room(id, name, description.toString().trim(), false);

                while ((line = br.readLine()) != null && !line.startsWith("ID = ") && !line.trim().isEmpty()) {
                    String[] exitSelection = line.split(" = ");
                    if (exitSelection.length == 2) {
                        String direction = exitSelection[0].trim().toUpperCase();
                        int roomDestination = Integer.parseInt(exitSelection[1].trim());
                        room.addExit(direction, roomDestination);
                    }
                }
                if (line != null && line.startsWith("ID = ")) {
                    continue;
                }
            }
        }
        if (room != null) {
            rooms.put(room.getRoomId(), room);
        }
        br.close();
    }

    public void play() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            if (currentRoom == null) {
                System.out.println("You are in a non-existent room.");
                System.exit(1);
            }

            currentRoom.setVisited(true);
            currentRoom.displayRoom();

            System.out.print("Enter a direction (or 'X' to exit): ");
            String command = scanner.nextLine().trim().toUpperCase();

            if (command.equals("X")) {
                System.out.println("Exiting the game.");
                break;
            }

            if (!currentRoom.getExits().containsKey(command)) {
                System.out.println("Invalid direction. Please try again.");
                continue;
            }

            Integer nextRoomId = currentRoom.getExits().get(command);

            if (nextRoomId == null) {
                System.out.println("The room in that direction does not exist.");
                continue;
            }

            Room nextRoom = rooms.get(nextRoomId);

            if (nextRoom != null) {
                currentRoom = nextRoom;
            } else {
                System.out.println("The room in that direction does not exist.");
            }
        }
        scanner.close();
    }

    public static void main(String[] args) {
        try {
            Game game = new Game("C:\\Users\\makit\\AppData\\Roaming\\JetBrains\\IntelliJIdea2022.3\\AdvancedProgrammingSummer\\src\\MinigameHW\\Rooms.txt");
            game.play();
        } catch (IOException ex) {
            System.err.println("Room file not available: " + ex.getMessage());
        }
    }
}